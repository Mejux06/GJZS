#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


rm -f $TMPDIR/update
am start -S $Package_name/com.projectkr.shell.SplashActivity
