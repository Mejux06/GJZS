#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


sh /data/data/Han.GJZS/files/kr-script//Block_Device_Name.sh | egrep '/logo|/splash'
