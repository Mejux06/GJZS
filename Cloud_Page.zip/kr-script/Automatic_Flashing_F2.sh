Magisk|Root系统
none|无