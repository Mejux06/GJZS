#本脚本由　by Han | 情非得已c，编写
#应用于搞机助手上


echo "0|默认布局"
echo "Cai|彩虹炫彩背景"
echo "Lan|蓝色炫彩背景"
echo "Fen|粉色炫彩背景"
echo "Hong|红色炫彩背景"
echo "Cheng|橙色炫彩背景"
echo "Lv|绿色炫彩背景"
echo "Qing|青色炫彩背景"
echo "Zi|紫色炫彩背景"
echo "ChunHong|纯红背景"
echo "ChunHuang|纯黄背景"
echo "ChunZi|纯紫背景"
echo "CaiSe|彩色背景"
echo "TouMing|透明背景"
